#include <iostream>
using namespace std;

int main (){
	int n;
	cout << "Masukan jumlah nilai dalam kumpulan: ";
	cin >> n;
	
	int *data = new int[n];
	cout << "Masukan nilai-nilai: ";
	for (int i = 0; i < n; ++i) {
		cin >> data[i];
	}
	int *maxPtr = &data[0];
	for (int i = 1; i < n; ++i) {
		if (data[i] > *maxPtr) {
			maxPtr = &data[i];
		}
	}
	
	cout << "Nilai maksimum adalah: " << *maxPtr << endl;
	cout << "Pointer menunjuk ke nilai maksimum: " << maxPtr << endl;
	
	delete[] data;
	return 0;
}
